from __future__ import annotations

from ..shared import AccountState, CargoOrderId, DefinitionId, EntityId, ProjectId, RouteId, SpatialNodeId
from ..site import SiteRequirements, evaluate_site_requirements
from .models import SourcingPolicy, ProjectStatus, ProjectComponentState, BuildProject, ProjectBlocker


class ConstructionPlanningMixin:
        def plan_build(
            self,
            facility_def_id: DefinitionId,
            location_id: SpatialNodeId,
            priority: int,
            sourcing_policy: SourcingPolicy,
            day: int = 0,
            import_source_id: SpatialNodeId | None = None,
        ) -> ProjectId:
            if facility_def_id not in self.recipes:
                raise KeyError(facility_def_id)
            if location_id not in self.facilities.environment.graph.nodes:
                raise KeyError(location_id)
            if sourcing_policy not in self.sourcing_wait_days:
                raise ValueError(f"unknown sourcing policy: {sourcing_policy}")
            recipe = self.recipes[facility_def_id]
            source = import_source_id
            if source is not None and source not in self.facilities.environment.graph.nodes:
                raise KeyError(source)
            self._counter += 1
            pid = ProjectId(f"project.{self._counter}")
            components = {c.component_id: ProjectComponentState() for c in recipe.components}
            self.projects[pid] = BuildProject(
                pid, facility_def_id, location_id, priority, sourcing_policy, source, components=components
            )
            return pid

        def set_priority(self, project_id: ProjectId, priority: int) -> None:
            self.projects[project_id].priority = priority

        def set_sourcing_policy(self, project_id: ProjectId, sourcing_policy: SourcingPolicy) -> None:
            if sourcing_policy not in self.sourcing_wait_days:
                raise ValueError(f"unknown sourcing policy: {sourcing_policy}")
            project = self.projects[project_id]
            if project.status not in {ProjectStatus.PLANNED, ProjectStatus.PROCURING}:
                raise ValueError("sourcing policy can only change before construction readiness")
            if any((c.import_committed_t or 0.0) > 1e-9 or c.import_order_id is not None for c in project.components.values()):
                raise ValueError("sourcing policy cannot change after import commitment")
            # Changing sourcing policy before commitment is a planning decision. Any
            # provisional local reservations are released so the new policy is applied
            # cleanly rather than inheriting hidden commitments from the old one.
            self.inventory.release_reservation(EntityId(project.id))
            for state in project.components.values():
                state.reserved_local_t = 0.0
                state.reserved_local_resource_id = None
                state.local_target_t = 0.0
            project.sourcing_policy = sourcing_policy
            project.procurement_started_day = None
            project.status = ProjectStatus.PLANNED

        def set_construction_weight(self, project_id: ProjectId, weight: float) -> None:
            if weight < 0:
                raise ValueError("construction weight must be non-negative")
            self.projects[project_id].construction_weight = weight

        def set_import_source(self, project_id: ProjectId, location_id: SpatialNodeId | None) -> None:
            project = self.projects[project_id]
            if location_id is not None and location_id not in self.facilities.environment.graph.nodes:
                raise KeyError(location_id)
            if project.status not in {ProjectStatus.PLANNED, ProjectStatus.PROCURING}:
                raise ValueError("import source can only change before construction readiness")
            if any((c.import_committed_t or 0.0) > 1e-9 or c.import_order_id is not None for c in project.components.values()):
                raise ValueError("import source cannot change after import commitment")
            if project.import_path is not None:
                if location_id is None:
                    raise ValueError("cannot clear import source while an explicit import path is selected")
                self.logistics.validate_path_structure(location_id, project.location_id, project.import_path)
            project.import_source_id = location_id

        def set_import_transport(
            self, project_id: ProjectId, path: tuple[RouteId, ...] | None, mode_by_route: dict[RouteId, str] | None = None
        ) -> None:
            project = self.projects[project_id]
            if project.status not in {ProjectStatus.PLANNED, ProjectStatus.PROCURING}:
                raise ValueError("import transport can only change before construction readiness")
            if any((c.import_committed_t or 0.0) > 1e-9 or c.import_order_id is not None for c in project.components.values()):
                raise ValueError("import transport cannot change after import commitment")
            selected_modes = {} if mode_by_route is None else dict(mode_by_route)
            if path is None:
                if selected_modes:
                    raise ValueError("explicit transport modes require an explicit import path")
            else:
                if project.import_source_id is None:
                    raise ValueError("import source must be selected before an explicit import path")
                self.logistics.validate_path_structure(project.import_source_id, project.location_id, path)
                self.logistics.validate_mode_selection(path, selected_modes, require_capacity=False)
            project.import_path = path
            project.import_mode_by_route = selected_modes

        def set_local_resource_choice(
            self, project_id: ProjectId, component_id: str, resource_id: DefinitionId | None, day: int = 0
        ) -> None:
            project = self.projects[project_id]
            if project.status not in {ProjectStatus.PLANNED, ProjectStatus.PROCURING}:
                raise ValueError("local material can only change before construction readiness")
            if component_id not in project.components:
                raise KeyError(component_id)
            state = project.components[component_id]
            if (state.import_committed_t or 0.0) > 1e-9 or state.import_order_id is not None:
                raise ValueError("local material cannot change after import commitment")
            component = next(c for c in self.recipes[project.facility_def_id].components if c.component_id == component_id)
            if resource_id is not None and resource_id not in {tier.local_resource_id for tier in component.local_tiers}:
                raise ValueError("resource is not a valid local substitution for this component")
            if state.reserved_local_t > 1e-12:
                if state.reserved_local_resource_id is None:
                    raise RuntimeError("local reservation lacks resource type")
                self.inventory.release_reserved_amount(
                    EntityId(project.id), project.location_id, state.reserved_local_resource_id, state.reserved_local_t
                )
                state.reserved_local_t = 0.0
                state.reserved_local_resource_id = None
            if resource_id is None:
                project.local_resource_choices.pop(component_id, None)
            else:
                project.local_resource_choices[component_id] = resource_id
            _resource, desired_local = self._selected_local_target(project, component, day)
            state.local_target_t = desired_local

        def set_local_fraction_target(
            self, project_id: ProjectId, component_id: str, fraction: float, day: int = 0
        ) -> None:
            if not 0.0 <= fraction <= 1.0:
                raise ValueError("local fraction must be between 0 and 1")
            project = self.projects[project_id]
            if project.status not in {ProjectStatus.PLANNED, ProjectStatus.PROCURING}:
                raise ValueError("local sourcing target can only change before construction readiness")
            if component_id not in project.components:
                raise KeyError(component_id)
            state = project.components[component_id]
            if (state.import_committed_t or 0.0) > 1e-9 or state.import_order_id is not None:
                raise ValueError("local sourcing target cannot change after import commitment")
            project.local_fraction_targets[component_id] = fraction
            component = next(c for c in self.recipes[project.facility_def_id].components if c.component_id == component_id)
            _resource, desired_local = self._selected_local_target(project, component, day)
            if state.reserved_local_t > desired_local + 1e-9 and state.reserved_local_resource_id is not None:
                release = state.reserved_local_t - desired_local
                self.inventory.release_reserved_amount(
                    EntityId(project.id), project.location_id, state.reserved_local_resource_id, release
                )
                state.reserved_local_t = desired_local
            state.local_target_t = desired_local

        def cancel(self, project_id: ProjectId) -> None:
            project = self.projects[project_id]
            if project.status in {ProjectStatus.COMPLETE, ProjectStatus.CANCELLED}:
                raise ValueError("project cannot be cancelled")
            # Before construction begins materials are only reserved and can be released.
            # Once work has started they are committed to the unfinished structure;
            # cancellation does not recreate consumed material. Salvage can be a
            # separate mechanic rather than an implicit full refund.
            if not project.materials_committed:
                self.inventory.release_reservation(EntityId(project.id))
                for state in project.components.values():
                    state.reserved_local_t = 0.0
                    state.reserved_local_resource_id = None
                    state.reserved_import_t = 0.0
            project.status = ProjectStatus.CANCELLED
            project.paused = False
            project.pause_started_day = None

        def pause(self, project_id: ProjectId, day: int) -> None:
            project = self.projects[project_id]
            if project.status in {ProjectStatus.COMPLETE, ProjectStatus.CANCELLED}:
                raise ValueError("project cannot be paused")
            if project.paused:
                return
            project.paused = True
            project.pause_started_day = day

        def resume(self, project_id: ProjectId, day: int) -> None:
            project = self.projects[project_id]
            if project.status in {ProjectStatus.COMPLETE, ProjectStatus.CANCELLED}:
                raise ValueError("project cannot be resumed")
            if not project.paused:
                return
            if project.procurement_started_day is not None and project.pause_started_day is not None:
                project.procurement_started_day += max(0, day - project.pause_started_day)
            project.paused = False
            project.pause_started_day = None


        def blockers(
            self, project_id: ProjectId, day: int = 0, power: PowerSnapshot | None = None
        ) -> tuple[ProjectBlocker, ...]:
            project = self.projects[project_id]
            if project.status in {ProjectStatus.COMPLETE, ProjectStatus.CANCELLED}:
                return ()
            recipe = self.recipes[project.facility_def_id]
            blockers: list[ProjectBlocker] = []
            if project.paused:
                blockers.append(ProjectBlocker("manual_pause", "建設案件が手動停止中"))
            missing_tech = recipe.prerequisite_technologies - self.unlocked_technologies
            if missing_tech:
                blockers.append(ProjectBlocker("technology", ",".join(sorted(map(str, missing_tech)))))
            site_power = power if power is not None else self.power.snapshot(project.location_id, self.facilities, day)
            for failure in self.site_failures(project.facility_def_id, project.location_id, day, site_power):
                blockers.append(ProjectBlocker(failure.code, failure.detail))
            if project.status == ProjectStatus.PROCURING:
                waited = 0 if project.procurement_started_day is None else day - project.procurement_started_day
                wait_limit = self.sourcing_wait_days[project.sourcing_policy]
                for component in recipe.components:
                    state = project.components[component.component_id]
                    if state.import_committed_t is not None:
                        if state.reserved_import_t + 1e-9 < state.import_committed_t:
                            blockers.append(ProjectBlocker("import_transit", component.component_id))
                        continue

                    _local_resource, desired_local = self._selected_local_target(project, component, day)
                    local_shortfall = max(0.0, desired_local - state.reserved_local_t)
                    if local_shortfall > 1e-9 and waited < wait_limit:
                        blockers.append(ProjectBlocker("local_supply_wait", component.component_id))
                        continue

                    import_amount = max(0.0, component.amount_t - state.reserved_local_t)
                    if import_amount <= 1e-9:
                        continue
                    if project.import_source_id is None:
                        blockers.append(ProjectBlocker("import_source", component.component_id))
                        continue
                    if self.inventory.available(project.import_source_id, component.import_resource_id) + 1e-9 < import_amount:
                        blockers.append(ProjectBlocker("import_stock", component.component_id))
                        continue
                    if not self.logistics.can_submit(
                        project.import_source_id, project.location_id, component.import_resource_id, import_amount, day,
                        project.import_path, project.import_mode_by_route,
                    ):
                        if project.import_path is None:
                            blockers.append(ProjectBlocker("import_route", component.component_id))
                        else:
                            detailed: list[str] = []
                            try:
                                self.logistics.validate_path_structure(project.import_source_id, project.location_id, project.import_path)
                                self.logistics.validate_mode_selection(project.import_path, project.import_mode_by_route, require_capacity=False)
                                for route_id in project.import_path:
                                    mode_id = project.import_mode_by_route.get(route_id)
                                    detailed.extend(
                                        f"{route_id}:{reason}"
                                        for reason in self.logistics.route_operational_failures(route_id, day, mode_id)
                                    )
                            except (KeyError, ValueError) as exc:
                                detailed.append(str(exc))
                            blockers.append(ProjectBlocker(
                                "import_transport",
                                component.component_id + (":" + ";".join(dict.fromkeys(detailed)) if detailed else ""),
                            ))

            if project.status in {ProjectStatus.READY, ProjectStatus.BUILDING} and not recipe.self_deploying and recipe.construction_work > 0:
                if project.construction_weight <= 1e-12:
                    blockers.append(ProjectBlocker("construction_allocation", "construction weight is zero"))
                if power is not None:
                    if self.construction_capacity_at(project.location_id, power, day) <= 1e-12:
                        blockers.append(ProjectBlocker("construction_capacity", "no usable construction flow"))
                else:
                    providers = [
                        facility for facility in self.facilities.active_compatible_at(project.location_id, day)
                        if facility.definition_id in self.construction_providers
                    ]
                    resource_capacity = any(
                        self.inventory.available(project.location_id, resource_id) > 1e-12 and spec.work_per_t_per_day > 0
                        for resource_id, spec in self.construction_resource_providers.items()
                    )
                    if not providers and not resource_capacity:
                        blockers.append(ProjectBlocker("construction_capacity", "no construction provider"))
            return tuple(blockers)
